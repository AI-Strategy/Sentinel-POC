# Dataset 03 (CSV Quoting + Missing Fields)

Highlights:
- CSV contains **quoted commas**, **extra columns**, and a **blank qty_authorized** row.
- Invoice includes a line with **sku=null**.
- Date formats vary (`17-Feb-2026` etc).
