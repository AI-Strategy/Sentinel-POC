# Dataset 04 (Corrupted XML + Numeric Weirdness)

Highlights:
- POD XML is **intentionally malformed** to force a parser error.
- Invoice contains a **decimal comma** price (`"3,25"`).
- A recovered/valid XML is included to test fallback paths.
