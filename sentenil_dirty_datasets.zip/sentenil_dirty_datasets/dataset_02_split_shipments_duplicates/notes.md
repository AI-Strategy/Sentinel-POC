# Dataset 02 (Split Shipments + Invoice Duplicates)

Highlights:
- Invoice has **duplicate SKU lines** that should be aggregated.
- POD has **split receipts** (same part_id appears multiple times).
- **Price variance**, **quantity mismatch**, and a **phantom line**.
- Multiple string/format issues (lowercase status, price as string, hyphen/space differences).
