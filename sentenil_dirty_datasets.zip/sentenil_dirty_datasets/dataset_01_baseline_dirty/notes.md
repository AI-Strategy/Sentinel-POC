# Dataset 01 (Baseline Dirty)

This set contains:
- **Price variance** (invoice vs PO)
- **Quantity mismatch** (invoice vs POD)
- **Phantom line** (invoice item has no PO/POD)
- **Null value** (billed_unit_price is null)
- **Fuzzy linking** needed across SKU/item_reference/part_id

Files:
- `invoice.json`
- `purchase_order.csv`
- `proof_of_delivery.xml`
- `ground_truth.json` (expected findings + file/line evidence)
