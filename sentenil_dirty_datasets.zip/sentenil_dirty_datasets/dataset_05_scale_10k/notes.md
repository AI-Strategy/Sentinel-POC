# Dataset 05 (Scale / 10k-ish)

Highlights:
- ~10k invoice lines (plus injected phantom invoice-only lines).
- Controlled rates for:
  - price variance
  - quantity mismatch
  - phantom lines
  - formatting noise (case, hyphens/spaces, padding)
- Includes `ground_truth_summary.json` (counts + injection params), not per-line evidence.
