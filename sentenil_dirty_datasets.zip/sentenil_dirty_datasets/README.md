# Sentenil Dirty Datasets (5 sets)

These datasets are designed to test "Ghost Invoice" reconciliation:
- **Invoice**: JSON (`invoice.json`)
- **Purchase Order**: CSV (`purchase_order.csv`)
- **Proof of Delivery**: XML (`proof_of_delivery.xml`)

## Line numbers
- All evidence line numbers are **1-based**.
- CSV line numbers include the header row as **line 1**.
- JSON and XML are formatted so each line item is on a single line to make evidence stable.

## Dataset index
1. `dataset_01_baseline_dirty`  
   Baseline: price variance, qty mismatch, phantom line, null value, fuzzy linking.

2. `dataset_02_split_shipments_duplicates`  
   Duplicate invoice SKU lines + split POD receipts.

3. `dataset_03_csv_quoting_missing_fields`  
   CSV quoting/extra columns + missing invoice SKU.

4. `dataset_04_corrupted_xml_numeric_weirdness`  
   Malformed XML + decimal comma numeric parsing.

5. `dataset_05_scale_10k`  
   ~10k lines for throughput testing with controlled error rates.
